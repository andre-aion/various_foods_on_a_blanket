create procedure BlockHashIntegrity(IN startBlock bigint(64))
  BEGIN
DECLARE i INT;
DECLARE parentHash TEXT;
DECLARE blockHash TEXT;
SELECT block_number INTO i FROM parser_state WHERE ID=1;
CREATE TEMPORARY TABLE BLK_ERROR(block_number bigint(64));
WHILE i>startBlock DO
  SELECT block_hash INTO blockHash FROM block WHERE block_number=i-1;
  SELECT parent_hash INTO parentHash FROM block WHERE block_number=i;
  IF blockHash != parentHash
  THEN INSERT INTO BLK_ERROR VALUES(i);
  END IF;
  SET i = i - 1;
END WHILE;
SELECT * FROM BLK_ERROR;
DROP TABLE BLK_ERROR;
END;

