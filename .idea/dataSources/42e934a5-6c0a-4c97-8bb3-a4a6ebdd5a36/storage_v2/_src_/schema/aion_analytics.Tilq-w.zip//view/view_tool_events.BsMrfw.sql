create view view_tool_events as (select `te`.`id`        AS `id`,
                                        `te`.`timestamp` AS `timestamp`,
                                        `t`.`name`       AS `tool`,
                                        `ten`.`name`     AS `event`,
                                        `tc`.`name`      AS `classification`
                                 from ((((`aion_analytics`.`tool_event` `te` left join `aion_analytics`.`tool_event_name` `ten` on ((
                                   `te`.`event` = `ten`.`id`))) left join `aion_analytics`.`tool` `t` on ((`te`.`tool` =
                                                                                                           `t`.`id`))) left join `aion_analytics`.`tool_has_classification` `thc` on ((
                                   `te`.`tool` = `thc`.`tool`))) join `aion_analytics`.`tool_classification` `tc` on ((
                                   `thc`.`classification` = `tc`.`id`))));

